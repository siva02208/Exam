﻿namespace Exam_back.Dto
{
    public class UserLoginDto
    {
        public string email {  get; set; }
        public string password { get; set; }
    }
}
